"""
    aec_800g.py

    Implementation of Credo AEC cable specific in addition to the CMIS specification.
"""

from ..public.cmisTargetFWUpgrade import CmisTargetFWUpgradeAPI

class CmisAec800gApi(CmisTargetFWUpgradeAPI):
    # Vendor specific implementation to be added here
    pass

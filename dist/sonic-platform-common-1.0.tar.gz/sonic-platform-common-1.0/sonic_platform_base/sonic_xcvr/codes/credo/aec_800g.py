from ..public.cmisTargetFWUpgrade import CmisTargetFWUpgradeCodes

class CmisAec800gCodes(CmisTargetFWUpgradeCodes):
    # Vendor specific implementation to be added here
    pass

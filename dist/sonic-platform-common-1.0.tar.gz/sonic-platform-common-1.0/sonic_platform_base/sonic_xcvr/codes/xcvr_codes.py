"""
    xcvr_codes.py

    Base class for representing codes used in xcvr memory maps
"""

class XcvrCodes(object):
    pass
